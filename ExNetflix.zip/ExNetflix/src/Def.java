
public class Def {
	
	//id's
	public static final int ALL_SHOWS = 1;
	public static final int DEAFULT_SERIESARRAY = 0; 

	//input
	public static final int PASSWORD_MIN = 6;
	public static final int NUMERIC_MIN = 47;
	public static final int NUMERIC_MAX = 54;
	public static final int LETER_MAX = 123;
	public static final int LETER_MIN = 65;
	
	//user data
	public static final int MEMBERSHIP_START = 0;
	// it doesn't connect to calendar
	public static final int MEMBERSHIP_END = MEMBERSHIP_START + 6;
	

}
