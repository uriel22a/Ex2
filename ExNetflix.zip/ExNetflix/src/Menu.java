import java.util.InputMismatchException;
import java.util.Scanner;

public class Menu {

	private static Login log = new Login();
	private static SeriesArray allShows;
	private SeriesArray watchedShows;
	private static Menu menu;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		menu = new Menu();
		allShows = new SeriesArray(Def.ALL_SHOWS);
		setwatchedShows();
		menu.logMenu();
		
	}	
	private static void setwatchedShows() {
		// TODO Auto-generated method stub
		menu.watchedShows = new SeriesArray(Def.DEAFULT_SERIESARRAY);
	}
	public void logMenu() {
		Scanner scann = new Scanner(System.in);
		String option = null;
		System.out.println("choose option");
		System.out.println("login");
		System.out.println("register");
		boolean flag = true;
		while(flag)
		{
			option = scann.next();
		
			if(option.contains("register")) {
				flag = false;
				log.createAcount();
				 menu.logMenu();
			}
			else if(option.contains("login")) {
				flag = false;
				if(log.getIn()) {
					menu.mainMenu();
				}
			}
		}
		
	}
	
	private void mainMenu() {
		// TODO Auto-generated method stub
		Scanner scann = new Scanner(System.in);
		boolean runing = true;
		while(runing) {
		System.out.println("choose");
		System.out.println("[1] all series");
		System.out.println("[2] continue series");
		System.out.println("[3] show detials");
		System.out.println("[4] choose series");
		System.out.println("[5] log out");
		String choose = scann.next();
		switch (choose) {
		case "1": 
		case "all series":	{
			allShows.print();
			break;}
		case "2": 
		case "continue series":{
			this.watchedShows.print();
			break;}
		case "3": 
		case "show detials":{	
			log.getLastUser().print();
			break;}
		case "4": 
		case "choose series":{	
			System.out.println("write specific series name (widout spaces)");
			String seriesName = scann.next();
			Series series = allShows.sarch(seriesName);
			boolean inThere = false;
			try {
			if(series != null) {	
				inThere = true;
				series.print();
					try {
					Series watchedSeries = this.watchedShows.sarch(seriesName);
					Episode[] episodes = watchedSeries.getEpisodes();
						boolean watched=false;	
						for (int i = episodes.length-1 ; i >= 0 ; i--) {
							if(episodes[i].isWatched())
							{
								watched = true;
								System.out.println("last episode watched: "+(i+1)+"");
							}
						}
						if(!watched)
							this.log.getLastUser().setSeriesWatch(this.log.getLastUser().getSeriesWatch()+1);	
						
					}catch (NullPointerException e) {
						this.watchedShows.addSeries(series);
						this.log.getLastUser().setSeriesWatch(this.log.getLastUser().getSeriesWatch()+1);	
					}
			}
			
			}catch (NullPointerException exeption) {
			}
			if(inThere) {		
			
				System.out.println("enter episode by number");
				int id=0;
				try {
				id = scann.nextInt();
				}catch (InputMismatchException e) {
					// TODO: handle exception
					boolean ok = false;
						while(ok) {
							try {
							scann.next();
							System.out.println("enter episode by number");
							id = scann.nextInt();
							}catch (InputMismatchException e2) {
								// TODO: handle exception
								ok=true;
							}
					}
				}
				
					series.getEpisodes()[id-1].setWatched(true);     
					this.watchedShows.addSeries(series);
					this.log.getLastUser().setEpisodeWatch(this.log.getLastUser().getEpisodeWatch()+1);
					System.out.println("episode "+id+" choosen");
					
				}else {
					System.out.println("series not found");
			}
			break;}	
		case "5": 
		case "log out":{
			runing = false;
			menu.logMenu();
			break;}	

		default:{	runing = true;
		break;}
					}
		}
		
	}
}