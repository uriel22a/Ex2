import java.util.Scanner;

public class Login {

	private User[] users;
	private User lastUser;
	public Login() {
		// TODO Auto-generated constructor stub
		users = new User[0];
		lastUser = new User(null, null);
	}	
	public boolean getIn() {
		Scanner scann = new Scanner(System.in);
		String Password = null;
		String userName = null;
		System.out.println("enter userName ");
		userName = scann.next();
		scann.nextLine();
		System.out.println("enter password ");
		Password = scann.next();
		if(checkAcount(Password,userName)) {
			this.lastUser = new User(Password, userName);
			return false;
		}
		return true;
		
	}
	
	public void createAcount () {
		Scanner scann = new Scanner(System.in);
		String Password = null;
		String userName = null;
		System.out.println("enter userName ");
		userName = scann.next();
		scann.nextLine();
		if(checkUser(userName)) {
			System.out.println("this userName allready occupied");
			createAcount();
		}
		System.out.println("enter password ");
		Password = scann.next();
		
		boolean passwordCorrect = passwordCheck(Password);
		while(!passwordCorrect) {
			System.out.println("password need at least 6 keys ,contain a number and a letter");
			System.out.println("enter password ");
			Password = scann.next();
			passwordCorrect = passwordCheck(Password);
		}
		
		addUser(Password,userName);
	}
	
	private boolean passwordCheck(String Password){
		
		if((Password .length() <= Def.PASSWORD_MIN))
			return false;
		
		boolean passwordCorrect = false;
		boolean userCorrect = false;
		
		for (int i = 0; i < Password.length(); i++) {
			if(Password.charAt(i) > Def.NUMERIC_MIN && Password.charAt(i) < Def.NUMERIC_MAX)
				passwordCorrect = true;
			if((Password.charAt(i) > Def.LETER_MIN )&&(Password.charAt(i) < Def.LETER_MAX))
				userCorrect = true;
		}	
		
		return (userCorrect && passwordCorrect);
	}	
	private boolean checkUser(String userName) {
		if((this.users != null) &&( userName!= null))
			for (int i = 0; i < this.users.length; i++) {
				if(userName.contains(this.users[i].getUserName()))
				{
					return true;
				}
			}
		return false;
	
	}
	
	
	private boolean checkAcount(String password,String userName){
		User currentUser = new User(password, userName);
		if((this.users != null) &&( currentUser!= null))
			for (int i = 0; i < this.users.length; i++) {
				if(currentUser == this.users[i])
				{
					return true;
				}
			}
		return false;
	}

	private void addUser(String password, String userName) {
		// adding to user array
		User currentUser = new User(password, userName);

		if(this.users == null) {
			this.users = new User[1];
			this.users[0] = currentUser;
		}
		else {
			User[] biggerArray = new User[this.users.length+1];
			for (int i = 0; i < this.users.length; i++) {
				biggerArray[i]=this.users[i];
			}
				biggerArray[this.users.length] = currentUser;
				this.users = biggerArray;
	
		}
	}
	private void removeUser(String password, String userName) {
		// remove from user array
		User currentUser = new User(password, userName);
			if(this.users != null) {
				User[] smallerArray = new User[this.users.length-1];
				
				for (int i = 0; i < this.users.length; i++) {
					if(this.users[i] == currentUser)
						smallerArray[i-1]=this.users[i];
					else {
						smallerArray[i]=this.users[i];
					}
						
				}
					this.users = smallerArray;
			}
		}
	public User getLastUser() {
		// TODO Auto-generated method stub
		return lastUser;
	}

}
