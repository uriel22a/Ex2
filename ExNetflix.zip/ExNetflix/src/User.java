
public class User {
	private String password;
	private String userName;
	
	private int memberStart;
	private int memberEnd;
	private int seriesWatch;
	private int episodeWatch;
	
	public User(String Password, String userName) {
		this.password = Password;
		this.userName = userName;
		this.memberStart = Def.MEMBERSHIP_START;
		this.memberEnd = Def.MEMBERSHIP_END;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void print() {
		System.out.println("your memberShip start before : "+ this.memberStart+" months");
		System.out.println("your memberShip end in : "+ this.memberEnd+" months");
		System.out.println("you watched "+this.seriesWatch +" series");
		System.out.println("you watched "+this.episodeWatch +" episodes");
	}

	//getters & setters
	public int getMemberStart() {
		return memberStart;
	}
	public int getMemberEnd() {
		return memberEnd;
	}
	public int getSeriesWatch() {
		return seriesWatch;
	}
	public int getEpisodeWatch() {
		return episodeWatch;
	}
	public void setMemberEnd(int memberEnd) {
		this.memberEnd = memberEnd;
	}
	public void setSeriesWatch(int seriesWatch) {
		this.seriesWatch = seriesWatch;
	}
	public void setEpisodeWatch(int episodeWatch) {
		this.episodeWatch = episodeWatch;
	}

}
