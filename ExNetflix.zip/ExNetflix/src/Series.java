
public class Series {
	public Episode[] getEpisodes() {
		return episodes;
	}

	public void setEpisodes(Episode[] episodes) {
		this.episodes = episodes;
	}

	private Episode[] episodes;
	private String name;
	private static Episode stopedEpisode;
	
	public Series(String name) {
		this.name = name;
		// edit 3 episodes
		this.episodes = new Episode[3];
		for (int i = 0; i < episodes.length; i++) {
			this.episodes[i] = new Episode(i+1);	
		}
	}
	
	public void print() {
		System.out.println(this.getName()+" episodes");
		for (int i = 0; i < episodes.length; i++) {
			episodes[i].print();
		}
	}
	// setters & getters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Episode getStopedEpisode() {
		return stopedEpisode;
	}
	
	public void setStopedEpisode(Episode stopedEpisode) {
		this.stopedEpisode = stopedEpisode;
	}

}
