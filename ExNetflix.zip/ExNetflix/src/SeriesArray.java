
public class SeriesArray {
private Series[] series;

public SeriesArray(int lebal) {
	// TODO Auto-generated constructor stub
	if(lebal == Def.ALL_SHOWS) {
	this.series = new Series[3];  
	series[0] = new Series("spongebob");
	series[1] = new Series("rick&morty");
	series[2] = new Series("lucifer");
	}else {
		this.series = new Series[0];
	}
	
}
public void addSeries(Series series) {
	// adding to user array
	Series currentSeries =series;

	if(this.series == null) {
		this.series = new Series[1];
		this.series[0] = currentSeries;
	}
	else {
		Series[] biggerArray = new Series[this.series.length+1];
		for (int i = 0; i < this.series.length; i++) {
			biggerArray[i]=this.series[i];
		}
			biggerArray[this.series.length] = currentSeries;
			this.series = biggerArray;

	}
}
public void removeSeries(Series series) {
	// remove from user array
	Series currentSeries = series;
		if(this.series != null) {
			boolean find = false ;
			Series[] smallerArray = new Series[this.series.length-1];
			for (int i = 0; i < this.series.length; i++) {
				if(this.series[i] == currentSeries)
					find = true;
				if (find) {
					smallerArray[i-1]=this.series[i];
				}else {
					smallerArray[i]=this.series[i];
				}
					
			}
				this.series = smallerArray;
		}
	}
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("all series :");
		for (int i = 1; i < series.length; i++) {
			if(!(series[i].getName().equals(series[i-1].getName())))
				System.out.println(series[i-1].getName());
		}
		System.out.println(series[series.length-1].getName());
	}
	public Series sarch(String name) {
		for (int i = 0; i < series.length; i++) {
			if(name.equals(series[i].getName()))
				return series[i];
		}
		return null;	
	}


}
