
public class Episode {

	private int number;
	private String name;
	private String summary;
	private String uploadDate;
	private boolean watched;
	public Episode(int number) {
		// TODO Auto-generated constructor stub
		this.number = number;
		this.setWatched(false);
		this.setSummary("");
		this.setUploadDate("");
		this.setName("episode");
	}
	public void print() {
		System.out.println(this.name+" "+this.number);
	}
	
	
	public int getNumber() {
		return number;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getUploadDate() {
		return uploadDate;
	}
	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isWatched() {
		return watched;
	}
	public void setWatched(boolean watched) {
		this.watched = watched;
	}
}
